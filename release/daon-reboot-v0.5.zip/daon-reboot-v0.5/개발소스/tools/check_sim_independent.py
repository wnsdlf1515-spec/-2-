"""Independent Python state transitions compared with JavaScript, including event variants."""
from pathlib import Path
import json,math,random,subprocess,itertools
root=Path(__file__).resolve().parents[1];R=json.loads((root/'design/rules-v0.5.json').read_text());cards={c['id']:c for c in R['cards']};events={e['id']:e for e in R['events']};rng=random.Random(1515)
rnd=lambda x:math.floor(x*10+.5)/10
rev=lambda p:12+max(-2,min(2,math.floor((p-10000)/100)))
def step(city,picks,eventId):
 p=city['period']+1;projects=city['projects']+[{'id':id,'ready':p+cards[id]['delay'],'started':p} for id in picks];active=[cards[t['id']] for t in projects if t['ready']<=p];ids={c['id'] for c in active};cost=sum(cards[id]['cost'] for id in picks);required=3+sum(c['upkeep'] for c in active);available=city['cash']+rev(city['population']);paid=min(required,available-cost);funding=paid/required;staff=12+sum(c['staff_supply'] for c in active);staffneed=8+sum(c['staff_need'] for c in active);ratio=min(1,staff/staffneed);util=min(funding,ratio)
 capacities=[R['initial']['capacity'][i]+sum(c['capacity'][i] for c in active)+sum(l['capacity'][i] for l in R['synergies'] if set(l['pair'])<=ids) for i in range(5)]
 effective=[rnd(c*(funding if i<2 else util)) for i,c in enumerate(capacities)]
 def needs(pop):return [rnd(R['demand_base'][i]+R['aging_per_period'][i]*p+(pop-10000)/100*R['demand_per_100_residents'][i]+events[eventId]['demand'][i]) for i in range(5)]
 d=needs(city['population']);settle=min(effective[0]/d[0],effective[1]/d[1]);migration=200 if settle>=1.08 else 100 if settle>=1 else -100 if settle<.85 else 0;population=city['population']+migration;d=needs(population);coverage=[min(1,v/d[i]) for i,v in enumerate(effective)];inc=max(0,min(100,70+sum(c['inclusion'] for c in active)*funding));quality=[rnd(min(coverage[:2])*100),rnd(min(coverage[2:4])*100),rnd((coverage[4]*100+inc)/2)]
 return {'period':p,'population':population,'cash':available-cost-paid,'projects':projects,'capacity':capacities,'effective':effective,'demand':d,'coverage':coverage,'inclusion':rnd(inc),'quality':quality,'utilization':util,'staff':staff,'staffNeed':staffneed,'upkeep':required}
cases=[];expected=[]
for n in range(300):
 city={'period':0,'population':10000,'cash':8,'projects':[]};order=['none']+list(rng.sample(['care','heat','housing'],2));path=[];states=[]
 for turn in range(3):
  available=city['cash']+rev(city['population']);used={p['id'] for p in city['projects']};opts=[[]]+[[id] for id in cards if id not in used and cards[id]['cost']<=available]
  opts += [[a,b] for a,b in itertools.combinations(cards,2) if a not in used and b not in used and a[0]!=b[0] and cards[a]['cost']+cards[b]['cost']<=available]
  picks=rng.choice(opts);city=step(city,picks,order[turn]);path.append(picks);states.append(city)
 cases.append({'path':path,'events':order});expected.append(states)
js="const E=require('./src/sim-engine');const cases=JSON.parse(require('fs').readFileSync(0,'utf8'));console.log(JSON.stringify(cases.map(c=>{let s=E.initial();return c.path.map((p,i)=>{s=E.resolve(s,p,c.events[i]).after;return s;});})));"
actual=json.loads(subprocess.run(['node','-e',js],cwd=root,input=json.dumps(cases),capture_output=True,text=True,check=True).stdout)
for n,(want,got) in enumerate(zip(expected,actual)):
 for t,(a,b) in enumerate(zip(want,got)):
  for key in a:
   if key=='projects':assert sorted(a[key],key=lambda x:x['id'])==sorted(b[key],key=lambda x:x['id'])
   elif key=='coverage':assert all(abs(x-y)<1e-10 for x,y in zip(a[key],b[key]))
   elif isinstance(a[key],float):assert abs(a[key]-b[key])<1e-10,(n,t,key,a[key],b[key])
   else:assert a[key]==b[key],(n,t,key,a[key],b[key])
report={'independent_paths':len(cases),'period_transitions':len(cases)*3,'status':'all match','event_conditions':'all ordered pairs from care/heat/housing'}
(root/'artifacts/sim-independent-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
