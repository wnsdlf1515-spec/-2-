const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const rules = JSON.stringify(JSON.parse(read('design/rules-v0.5.json'))).replace(/</g,'\\u003c');
const script = ['window.DaonRules = '+rules+';',read('src/sim-engine.js'),read('src/content.js'),read('src/sim-visuals.js'),read('src/sim-materials.js'),read('src/sim-app.js')].join('\n');
const html = `<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#12625c"><title>다온시 리부트 · 우리 반이 도시를 살린다</title><style>${read('src/session-style.css')}\n${read('src/sim-style.css')}</style></head>
<body><a class="skip-link" href="#main">본문으로 이동</a><div id="app"></div><dialog id="dialog" aria-labelledby="dialog-title"></dialog><div id="toast" role="status" aria-live="polite"></div><input id="import-file" type="file" accept=".json,application/json" hidden><noscript>이 게임은 브라우저의 JavaScript 사용 설정이 필요합니다.</noscript><script>${script.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
fs.mkdirSync(path.join(root,'release'),{recursive:true});
fs.writeFileSync(path.join(root,'release/index.html'),html);
console.log('Built release/index.html ('+Math.round(Buffer.byteLength(html)/1024)+' KB), no external runtime dependencies.');
