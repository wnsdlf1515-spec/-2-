"""Independent exhaustive arithmetic check against the JavaScript session engine."""
import itertools,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
r=json.loads((root/'design/rules-v0.4.json').read_text())
depts=['Y','E','C','H','I']
plans=list(itertools.product(*[[c for c in r['cards'] if c['department']==d] for d in depts]))
js="""const E=require('./src/session-engine.js');const rows=JSON.parse(require('fs').readFileSync(0,'utf8'));console.log(JSON.stringify(rows.map(ids=>{let s=E.advance(E.initial());for(const id of ids)s=E.choose(s,id);return E.result(s)})));"""
computed=json.loads(subprocess.run(['node','-e',js],cwd=root,input=json.dumps([[c['id'] for c in cs] for cs in plans]),text=True,check=True,capture_output=True).stdout)
legal=0;wins=[];usage={c['id']:0 for c in r['cards']}
for cs,got in zip(plans,computed):
    ids={c['id'] for c in cs};cost=sum(c['cost'] for c in cs);upkeep=sum(c['upkeep'] for c in cs)
    event=r['events'][0];effect=event['mitigated'] if ids.intersection(event['protectors']) else event['base']
    base=[r['initial'][i]+r['trend'][i]+effect[i]+sum(c['now'][i] for c in cs)+sum(l['effect'][i] for l in r['synergies'] if set(l['pair'])<=ids) for i in range(5)]
    final=[v+sum(c['next'][i] for c in cs) for i,v in enumerate(base)]
    reserve=r['budget']-cost-upkeep;goal=r['goal']
    success=cost<=r['execution_limit'] and min(final)>=goal['minimum'] and sum(final)>=5*goal['average'] and reserve>=goal['reserve'] and upkeep<=goal['max_upkeep']
    assert got['immediate']==base and got['final']==final and got['reserve']==reserve and got['success']==success
    legal+=cost<=r['execution_limit']
    if success:
        wins.append(ids)
        for c in ids:usage[c]+=1
# Minimum replacements from any legal first agreement to a successful plan.
repairs={}
for cs in plans:
    if sum(c['cost'] for c in cs)>r['execution_limit']:continue
    ids={c['id'] for c in cs};distance=min(len(ids-w) for w in wins);repairs[distance]=repairs.get(distance,0)+1
report={'combinations':len(plans),'legal':legal,'successful':len(wins),'winning_usage_by_card':usage,'minimum_replacements_to_success':repairs,'independent_comparison':'all 243 match'}
(root/'artifacts/session-design-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
assert all(usage.values()) and max(repairs)<=3
