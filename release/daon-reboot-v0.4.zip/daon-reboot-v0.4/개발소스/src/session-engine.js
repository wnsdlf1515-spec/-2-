(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('../design/rules-v0.4.json'));else root.CitySession=factory(root.DaonRules);})(typeof globalThis!=='undefined'?globalThis:this,function(R){
'use strict';
const D=['Y','E','C','H','I'], phases=['brief','plan','response','build','operation','final'];
const cards=Object.fromEntries(R.cards.map(c=>[c.id,c])), clone=x=>JSON.parse(JSON.stringify(x));
const budget=R.budget,limit=R.execution_limit,event=R.events.find(e=>e.id==='care');
const text=v=>typeof v==='string'&&v.length<=1500;
function initial(){return {version:'single-1',phase:'brief',selected:{},proposal:null,notes:Object.fromEntries(D.map(d=>[d,{reason:'',review:'',checked:false}])),reflection:'',minutes:50};}
function selected(s){return D.map(d=>s.selected[d]).filter(Boolean);}
function error(s){const ids=selected(s);if(ids.length!==5)return '다섯 부서에서 정책을 하나씩 선택해 주세요.';if(ids.reduce((n,id)=>n+cards[id].cost,0)>limit)return '집행 한도 22칩을 넘었습니다. 정책을 조정해 주세요.';return '';}
function result(s){
 const ids=selected(s),cost=ids.reduce((n,id)=>n+cards[id].cost,0),upkeep=ids.reduce((n,id)=>n+cards[id].upkeep,0),lines=[];
 const add=(kind,label,vector)=>lines.push({kind,label,vector:[...vector]});
 ids.forEach(id=>add('policy',cards[id].name,cards[id].now));
 const links=R.synergies.filter(l=>l.pair.every(id=>ids.includes(id)));
 links.forEach(l=>add('synergy',l.pair.map(id=>cards[id].name).join(' + '),l.effect));
 const protectedBy=event.protectors.filter(id=>ids.includes(id));
 add('event',event.name+(protectedBy.length?' · 대응 정책으로 완화':' · 기본 영향'),protectedBy.length?event.mitigated:event.base);
 add('trend','관찰 기간의 미해결 서비스 공백',R.trend);
 const sum=ls=>ls.reduce((v,l)=>v.map((x,i)=>x+l.vector[i]),[...R.initial]).map(v=>Math.max(0,Math.min(100,v)));
 const immediate=sum(lines);
 ids.forEach(id=>add('delayed',cards[id].name+' · 운영 이후 1회',cards[id].next));
 const final=sum(lines),reserve=budget-cost-upkeep;
 const checks=[...D.map((d,i)=>({label:R.metrics[i],value:final[i],target:R.goal.minimum,pass:final[i]>=R.goal.minimum})),{label:'평균 생활 여건',value:final.reduce((a,b)=>a+b,0)/5,target:R.goal.average,pass:final.reduce((a,b)=>a+b,0)>=R.goal.average*5},{label:'예비비',value:reserve,target:R.goal.reserve,pass:reserve>=R.goal.reserve},{label:'이후 운영 부담',value:upkeep,target:R.goal.max_upkeep,upper:true,pass:upkeep<=R.goal.max_upkeep}];
 return {ids,cost,upkeep,reserve,immediate,final,lines,links,protectedBy,checks,success:!error(s)&&checks.every(c=>c.pass)};
}
function choose(s,id){if(!['plan','response'].includes(s.phase))throw Error('계획·수정 회의에서만 정책을 바꿀 수 있습니다.');if(!cards[id])throw Error('알 수 없는 정책입니다.');const n=clone(s);n.selected[cards[id].department]=id;return n;}
function advance(s){if(s.phase==='final')throw Error('수업을 마쳤습니다.');if(['plan','response'].includes(s.phase)&&error(s))throw Error(error(s));const n=clone(s);if(s.phase==='plan')n.proposal=clone(s.selected);n.phase=phases[phases.indexOf(s.phase)+1];return n;}
function validate(s){
 if(!s||s.version!=='single-1')throw Error('한 턴 완결형 v0.4의 저장 파일만 열 수 있습니다. 이전 v0.3 기록은 이전 실행본에서 열어 주세요.');
 if(!phases.includes(s.phase)||!s.selected||typeof s.selected!=='object'||Array.isArray(s.selected))throw Error('진행 상태가 올바르지 않습니다.');
 const validPick=p=>p&&typeof p==='object'&&!Array.isArray(p)&&Object.entries(p).every(([d,id])=>D.includes(d)&&cards[id]?.department===d);
 if(!validPick(s.selected))throw Error('정책 선택이 올바르지 않습니다.');
 if(s.phase==='brief'&&selected(s).length)throw Error('시작 상태에 실행 정책이 있습니다.');
 if(!text(s.reflection)||!Number.isInteger(s.minutes)||s.minutes<30||s.minutes>90)throw Error('설정 또는 기록이 올바르지 않습니다.');
 if(!s.notes||!D.every(d=>s.notes[d]&&text(s.notes[d].reason)&&text(s.notes[d].review)&&typeof s.notes[d].checked==='boolean'))throw Error('부서 기록이 올바르지 않습니다.');
 if(phases.indexOf(s.phase)>=2){if(!validPick(s.proposal)||error({...s,selected:s.proposal}))throw Error('최초 합의 기록이 올바르지 않습니다.');}else if(s.proposal!==null)throw Error('최초 합의 기록 시점이 올바르지 않습니다.');
 if(phases.indexOf(s.phase)>=3&&error(s))throw Error(error(s));
 return {version:'single-1',phase:s.phase,selected:clone(s.selected),proposal:clone(s.proposal),notes:clone(s.notes),reflection:s.reflection,minutes:s.minutes};
}
function parse(raw){if(typeof raw!=='string'||raw.length>1000000)throw Error('저장 파일 크기가 올바르지 않습니다.');let p;try{p=JSON.parse(raw);}catch{throw Error('JSON 저장 파일을 읽을 수 없습니다.');}if(!p||!Array.isArray(p.history)||p.history.length>60)throw Error('취소 기록이 올바르지 않습니다.');return {state:validate(p.state),history:p.history.map(validate)};}
return {R,D,phases,cards,clone,budget,limit,event,initial,selected,error,result,choose,advance,validate,parse};
});
