# 다온시 리부트 v0.4 — 현재 개발 안내

현재 앱은 한 턴 완결형입니다. `docs/PROJECT_STATE.md`의 최신 체크포인트를 먼저 읽으세요. 활성 소스는 `src/session-*`와 `src/content.js`, 규칙은 `design/rules-v0.4.json`입니다. 기존 v0.1–v0.3 자료는 과거 기록으로 보존합니다.

`npm ci --ignore-scripts` → `npm run build` → `npm test` → `npm run test:design` → `npm run test:browser`. 브라우저 검사는 `/usr/bin/chromium`과 로컬 포트 사용 권한이 필요합니다. `npm start`는 내부 확인용 서버입니다. 배포는 `release/index.html` 단독 실행입니다.

# 다온시 리부트: 우리 반이 도시를 살린다

통합사회2 인구 문제 공개수업용 협력 정책 게임. **교사용 실행본 v0.2**.
교사 PC 한 대와 모둠 인쇄물로 3턴 × 2회 도전을 진행합니다. 학생 계정·서버·게임 중 AI 호출이 필요 없습니다.

## 실행과 수업 자료

- `release/index.html`: CSS·규칙·화면을 모두 담은 단일 HTML. 내려받아 Chrome 또는 Edge에서 엽니다.
- `release/다온시-수업자료.pdf`: 지도안, 교사 안내, 5부서 활동지, 비교·퇴장표, 정책·사건 설계표. A4 10쪽.
- `release/다온시-수업꾸러미-v0.2.zip`: 실행본·PDF·시작 안내·설계 및 이어가기 문서.
- [교사 시작 안내](docs/teacher-guide-v0.2.md)
- [핵심 설계 v0.1](docs/core-design-v0.1.md)
- [개발·검증 보고서](docs/implementation-validation-v0.2.md)
- [다음 작업을 위한 기록](docs/PROJECT_STATE.md)

첫 실행에서 ‘1턴 연습’을 먼저 해 보세요. 본 수업은 ‘정책회의 시작하기’로 시작합니다. 3턴 뒤 ‘같은 조건으로 재도전’을 선택하면 덱·사건·초기값을 복원합니다. 추가 능력치·예산 보상은 없습니다.

정책 선택과 메모는 브라우저에 자동 저장됩니다. 다른 PC로 옮기거나 수업을 종료하기 전에 ‘저장·설정 → 수업 기록 내보내기’로 JSON을 보관하세요. 파일을 불러오기 전에 규칙 버전·초기값·정책 선택을 검증하며 기존 기록은 이전 백업에 보관합니다.

**검증 범위:** 실제 Chromium에서 도전·재도전·복구를 검사하고 네트워크 차단 상태에서도 한 도전 전체를 진행했습니다. 이 클라우드 브라우저는 관리자 정책으로 `file://` 열기를 차단하므로, 내려받은 파일 직접 열기는 수업할 PC에서 확인해야 합니다. 교실 뒤 가독성·50분 운영·학습 효과도 현장 검증 전입니다.

## 개발

게임 빌드와 규칙 테스트는 Node.js 20 이상으로 실행합니다. 런타임 외부 패키지는 없습니다.

```sh
node tools/build.cjs
node --test tests/engine.test.cjs
```

실제 브라우저 검사는 Playwright 1.62.1과 Chromium을 사용합니다.

```sh
npm ci
npm run test:browser
```

기본 Chromium 경로는 `/usr/bin/chromium`입니다. 다른 경로는 `DAON_CHROMIUM` 환경 변수로 지정합니다. 이 환경에는 Chromium이 설치되어 있습니다. 브라우저 검사는 자체 로컬 서버를 열고 종료하며 PDF와 테스트 증거를 생성합니다.

개발 중 서버가 필요하면 Python 3으로 `npm start`를 실행합니다. `release/`만 제공합니다. 클라우드 온보딩 화면에 localhost 미리보기 링크를 노출하지 않습니다. 태스크는 이미 격리되어 있으므로 기존 `/workspace/-2-`에서 작업하며 명시적 요청 없이 별도 worktree를 만들지 않습니다.

수치 설계의 전수검사를 다시 할 때만 `python3 tools/check_design.py`를 실행합니다. 이미 통과한 수치 검사를 단순 화면 수정마다 반복할 필요는 없습니다. 검사 후 꾸러미 생성: `python3 tools/package_release.py`.

## 구조

- `design/rules-v0.1.json`: 검토 가능한 효과·사건·목표 기준
- `src/engine.js`: 상태 변환·계산·재현·저장 검증. DOM과 분리
- `src/app.js`: 교사 화면, 수동 진행, 기록, 타이머, 되돌림
- `src/content.js`: 카드 작동 원리·상충 설명
- `src/materials.js`: 인쇄 자료. 수치 표는 규칙 데이터에서 생성
- `src/style.css`: 교실·모바일·A4 인쇄 스타일
- `tools/build.cjs`: 단일 HTML 생성
- `tests/engine.test.cjs`, `tests/browser.cjs`: 규칙·실제 브라우저 검증

모든 인구 자료와 정책 수치는 수업용 가정입니다. 실제 정책 효과를 예측하거나 승패로 학생을 평가하지 않습니다.
